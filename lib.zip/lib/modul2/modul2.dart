import 'package:flutter/material.dart';

class Modul2Page extends StatelessWidget {
  const Modul2Page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Row and Column'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Baris pertama
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                KotakWarnaJempol(warna: Colors.blue, text: 'Kotak 1'),
                const SizedBox(width: 10),
                KotakWarnaJempol(warna: Colors.yellow, text: 'Kotak 2'),
              ],
            ),

            const SizedBox(height: 10),

            // Baris kedua
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                KotakWarnaJempol(warna: Colors.greenAccent, text: 'Kotak 3'),
                const SizedBox(width: 10),
                KotakWarnaJempol(warna: Colors.purpleAccent, text: 'Kotak 4'),
              ],
            ),

            const SizedBox(height: 30),

            // Tombol kembali ke menu utama
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Back To Menu'),
            ),
          ],
        ),
      ),
    );
  }
}

class KotakWarnaJempol extends StatelessWidget {
  final Color warna;
  final String text;

  const KotakWarnaJempol({super.key, required this.warna, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        color: warna,
        border: Border.all(color: Colors.black, width: 1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.favorite, color: Colors.red, size: 40),
          Text(text, style: const TextStyle(color: Colors.black)),
        ],
      ),
    );
  }
}
